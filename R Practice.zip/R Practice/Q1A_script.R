# Example 4:  Create Chart using ChartSeries on any stock/ INFY.NS
# adding  SMA26 & SMA 9, 
# identify latest bullish/ bearish cross over and provide next trading strat

# Setup working directory

# Step1: install & load packages
install.packages(c("quantmod","tidyverse"))

#I am skipping above step as already have packages installed

library(quantmod) # includes TTR, xts,zoo
library(TTR) # loading is required even if included in quantmod
library(tidyverse) # includes dplyr, tibble
library(xts) # auto loaded with quantmod

# Step 2: read data from CSV
TA_data <- read.csv("Data1.csv")
unique(TA_data$Stock)

# Selected Company "INFY.NS"
INFY.NS_TA <- TA_data[TA_data$Stock =="INFY.NS",]
Rel_data <- TA_data[TA_data$Stock == "RELIANCE.NS",]
str(INFY.NS_TA) # checking of date column is in date format and not chr 

# 2.1 convert date columns class
INFY.NS_TA$Date <-as.Date(INFY.NS_TA$Date)
str(INFY.NS_TA)

# Step 3: convert data to xts by Date column of data 
INFY_xts <- xts(INFY.NS_TA[,2:6],order.by = INFY.NS_TA$Date) # imp to remember Stock & Date columns are not required for assessment
str(INFY_xts)
class(INFY_xts$Close)

# Step 4: data quality check {check is.na, volume == 0 and duplicated dates and if true drop that line}
sum(is.na(INFY_xts))
sum(duplicated(index(INFY_xts)))
sum(INFY_xts$Volume==0)

# dropping observations with above data quality
INFY_xts <- INFY_xts[INFY_xts$Volume!= 0,]
length(index(INFY_xts))

# Step 5: Creating chart using chartSeries function of quantmod, 
# adding SMA26 & SMA 9 using subset to zoom into the chart where we see latest crossover

chartSeries(INFY_xts, theme = chartTheme("white"),subset = "last 2 weeks")
addSMA(n=26, col= "brown")
addSMA(n=9, col= "blue")
dev.off()

# to find latest crossover we zoom in chart using subset

# so latest crossover is bearish corssover as of August 25 and strategy will be to go short.
# we saved the chart by right click and save as image.
# Alternatively we can use png function before chart Series and run the entire code together to create the chart& save as png

png("TA_Chart_Infy.png", 1000,960, res=150)
chartSeries(INFY_xts, theme = chartTheme("white"), subset = "2026-07::2026-10")
addSMA(n=26,col= "brown")
addSMA(n=9,col= "blue")
dev.off()

# End of Example 4


















