# set up working directory....
# # Let�s take an example of Technical analysis in R  using quantmod and TTR packages

#Step 1: install & Load Packages

install.packages(c("quantmod","tidyverse"))
# I am skipping above step as already have packages installed

library(quantmod) # includes TTR, xts,zoo
library(TTR) # loading is required even if included in quantmod
library(tidyverse) # includes dplyr, tibble
library(xts) # auto loaded with quantmod

# Step 2: read data from CSV
TA_data <- read.csv("Data1.csv")
unique(TA_data$Stock)
# Selected company "INFY.NS"

INFY.NS_TA <- TA_data[TA_data$Stock =="INFY.NS",]
str(INFY.NS_TA)

# observe date column is of character class, we need to first convert it to date format

# 2.1 convert date columns class
INFY.NS_TA$Date <-as.Date(INFY.NS_TA$Date)
str(INFY.NS_TA)

# Step 3: convert data to xts by Date column of data 
INFY_xts <- xts(INFY.NS_TA[,2:6],order.by = INFY.NS_TA$Date) # imp to remember Stock & Date columns are not required for assessment
str(INFY_xts)
str(INFY_xts$Close)

# Step 4: data quality check {check is.na, volume == 0 and duplicated dates and if true drop that line}

sum(is.na(INFY_xts))
sum(duplicated(index(INFY_xts)))
sum(INFY_xts$Volume==0)

# dropping observations with above data quality
INFY_xts <- INFY_xts[INFY_xts$Volume!= 0,]
length(index(INFY_xts))

#Step5:  Identify Bullish(Golden) cross and Bearish(Death) cross using EMA50 & EMA200
# note: Golden Crossover and Death cross overs are specific crossover identified using long term trendlines.

price <- Cl(INFY_xts) # INFY_xts$Close

# calculate EMAs
EMA50 <- EMA(price,n=50)
EMA200 <-EMA(price,n=200)

Golden_cross <- lag(EMA50)< lag(EMA200) & EMA50 > EMA200 # logical output (True if conditions satisfied)
Death_cross <- lag(EMA50) > lag(EMA200) & EMA50 < EMA200

# count Golden Cross and Death Cross

sum(Golden_cross,na.rm = T)
sum(Death_cross,na.rm = T)

# Step 6: identification of trend FastMA > slow MA = Bullish, Otherwise Bearish
trend <- ifelse(EMA50>EMA200,"Bullish","Bearish")

# count number of days of Bullish/ bearish trend

sum(trend =="Bullish",na.rm = T)
sum(trend !="Bullish",na.rm = T)

# Step 7:  create a data frame

INFY_df <- data.frame(
  Date = index(INFY_xts),
  Open = as.numeric(INFY_xts$Open),
  High = as.numeric(INFY_xts$High),
  Low = as.numeric(INFY_xts$Low),
  Close = as.numeric(INFY_xts$Close),
  Volume = as.numeric(INFY_xts$Volume),
  EMA50 = as.numeric(EMA50),
  EMA200 = as.numeric(EMA200),
  GoldenCross = as.logical(Golden_cross),
  DeathCross = as.logical(Death_cross),
  Trend = as.character(trend)  
  )

# Step7: export to CSV

write.csv(INFY_df, "TechnicalAnalysis.csv", row.names = F)

# we can review above table and identify the trading signal based on crossovers and trend.

# End of Example














