############################ Q1A ################################

#Step 1
install.packages(c("quantmod", "tidyverse"))

library(quantmod)
library(TTR)
library(tidyverse)
library(xts)

#Step 1
data <- read.csv("C:/Users/aarya/Desktop/R Practice/Data1.csv")
unique(data$Stock)

infy.ns <- data[data$Stock == "INFY.NS",]
rel <- data[data$Stock == "RELIANCE.NS",]
str(infy.ns)

#Step 2.1
infy.ns$Date <- as.Date(infy.ns$Date)
str(infy.ns)

#Step 3
infy.xts <- xts(infy.ns[,2:6],order.by = infy.ns$Date)
str(infy.xts)

#step 4
sum(is.na(infy.xts))
sum(duplicated(index(infy.xts)))
sum(infy.xts$Volume==0)

infy.xts <- infy.xts[infy.xts$Volume!=0,]
length(index(infy.xts))

#Step 5
chartSeries(infy.xts, theme = chartTheme("white"), subset = "last 2 weeks")
addSMA(n=26, col="brown")
addSMA(n=9, col = "blue")
dev.off()

png("Chart-infy.png", 1000, 960, res = 150)
chartSeries(infy.xts, theme = chartTheme("white"), subset = "2026-07::2026-10")
addSMA(n=26, col="brown")
addSMA(n=9, col="blue")
dev.off()

############################ Q1B ################################


