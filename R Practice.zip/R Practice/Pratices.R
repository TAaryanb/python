install.packages(c("quantmod","tidyverse"))

library(quantmod)
library(tidyverse)
library(TTR)
library(xts)

data <- read.csv("C:/Users/aarya/Desktop/R Practice/Data1.csv")
unique(data$Stock)

infy.ns <- data[data$Stock == "INFY.NS",]
str(infy.ns)

infy.ns$Date <- as.Date(infy.ns$Date)
str(infy.ns)

infy.xts <- xts(infy.ns[,2:6], order.by = infy.ns$Date)
str(infy.xts)
str(infy.xts$Close)

sum(is.na(infy.xts))
sum(duplicated(index(infy.xts)))
sum(infy.xts$Volume==0)

infy.xts <- infy.xts[infy.xts$Volume!=0,]
length(index(infy.xts))

price <- C1(infy.xts)
EMA50 <- EMA50(price, n=50)
EMA200 <- EMA200(price, n=200)

goldenCross <- lag(EMA50) < lag(EMA200) & EMA50 > EMA200
deathCross <- lag(EMA50) > lag(EMA200) & EMA50 < EMA200

sum(goldenCross, na.rm = T)
sum(deathCross, na.rm = T)

trend <- ifelse(EMA50>EMA200,"Bullish", "Bearish")

sum(tread == "Bullish", na.rm = T)
sum(trend != "Bullish", na.rm = T)

infy.df <- data.frame(
  Date = index(infy.xts),
  Open = as.numeric(infy.xts$Open),
  High = as.numeric(infy.xts$High),
  Low = as.numeric(infy.xts$Low),
  Close = as.numeric(infy.xts$Close),
  Volume = as.numeric(infy.xts$Volume),
  EMA50 = as.numeric(EMA50)
  EMA200 = as.numeric(EMA200)
  goldenCross = as.logical(goldenCross),
  deathCross = as.logical(deathCross),
  Trend = as.character(trend)
)

write.csv(infy.df,"TechnicalAnalysis.csv", row.name = F)