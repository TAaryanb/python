# Example 1: Stats
# Objective: Perform Descriptive Statistical Analysis in R
# Expected: Calculate Mean, Median, Mode, Minimum, Maximum, Range, Q1, Q3, IQR
# Standard Deviation, Variance, Coefficient of variation, Skewness and Kurtosis
# Store the results in data frame and export the results to csv.

# Step 1 Set the working directory ( we have already set wd)
# Assume Data2 is to be used for Descriptive Statistical Analysis/Calculations

# Step 2: Install &  Load Required packages 
# All basic statistical metrics such  as mean, median can be directly calculated
# using functions available in base R or Stats package
# for calculation of Mode we will use mlv function of modeest package
# for calculation of Coeff of Skewness & Kurtosis we will use package moments

install.packages(c("moments","modeest")) # installation of package requires internet connection
# (since i already have these packages installed i am skipping this step)

# load Packages

library(modeest)
library(moments)

# Reading the data and basic checks

data_ds <-read.csv("Data2.csv")
data_bankY <- data_ds[data_ds$Bank=="BankY",]
str(data_bankY)

# Data is huge and we should first identify the variable/ column on which we want to perform analysis.
# Assuming we want to perform analysis on Sales for FY 2026 and hence we need exact name of column/ variable from data frame.

names(data_bankY) # this fucntion displays names of all variables under selected data frame.

# we have identified variable as "FY2026_Sales_Cr". lets select this variable for analysis.

sales_fy26 <- na.omit(data_bankY$FY2026_Sales_Cr) # creating R object for selected data and removing na/ blank cell if any.

# observed 248 data points/ observations (i.e. 2 blank /na data points were omitted)

# Step 4: calculate and store metrics in data frame.

range(sales_fy26)
rng <- max(sales_fy26)-min(sales_fy26)

# defining a vector containing Names of metrics to be calculated

Statistics <- c("Mean", "Median", "Mode", "Minimum", "Maximum", "Range", "Quartile-1", "Quartile-3", 
                "InterQuartileRange", "StandardDeviation", "Variance", "Coeff.Variation ",
                "Coeff.Skewness ","Coeff.Kurtosis")

# now defining another vector containing actual calculated values for metrics in same order as above vector

Value <- c(mean(sales_fy26),median(sales_fy26),modeest::mlv(sales_fy26), min(sales_fy26),max(sales_fy26),
           (max(sales_fy26)-min(sales_fy26)), quantile(sales_fy26,0.25), quantile(sales_fy26,0.75),
           (quantile(sales_fy26,0.75)-quantile(sales_fy26,0.25)), sd(sales_fy26), var(sales_fy26),
           (sd(sales_fy26)/mean(sales_fy26)), moments::skewness(sales_fy26), moments::kurtosis(sales_fy26)
)

options(scipen = 999)

# store as data frame

DS_df <- data.frame(Statistics,	Value = round(Value,4)) # stores values rounded off up to 4 digits

mean(sales_fy26)
moments::skewness(sales_fy26)
moments::kurtosis(sales_fy26)
# write/ export to  CSV

write.csv(DS_df,"DescriptiveStats_data2.csv", row.names = F) # no row lables






