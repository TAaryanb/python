# Setting WD

# Library

# read Data

data2 <- read.csv("Data2.csv")
data_bankY <- data2[data2$Bank=="BankY",]
names(data_bankY)
reg_data <- na.omit(data_bankY[,13:22])
str(reg_data)

covariance_matrix <- cov(reg_data)
write.csv(covariance_matrix,"cov_matrix.csv")


correlation_matrix <- cor(reg_data)
write.csv(correlation_matrix,"cor_matrix.csv")

# regression model fitting

args(lm)
reg_model <- lm(CredScore_FY2026 ~ FY2026_TotalAssets_Cr + FY2026_CurrentAssets_Cr +
                  FY2026_CurrentLiabilities_Cr+ FY2026_RetainedEarnings_Cr+
                  FY2026_EBIT_Cr + FY2026_MarketValueEquity_Cr + 
                  FY2026_TotalDebt_Cr + FY2026_TotalLiabilities_Cr + 
                  FY2026_Sales_Cr, data= reg_data)
options(scipen = 999)
summary(reg_model)

capture.output(summary(reg_model),file = "Regression_Result.txt")

